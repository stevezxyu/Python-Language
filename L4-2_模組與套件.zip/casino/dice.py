from random import choice

def roll_dice():
	return choice(range(1, 7))