from statspy import mean_module, sd_module

print(mean_module.my_mean(range(1, 101)))
print(sd_module.my_sd(range(1, 101)))