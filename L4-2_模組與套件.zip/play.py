from casino import dice, poker

print(dice.roll_dice())
print(poker.deal_card())