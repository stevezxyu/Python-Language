import sys

def squared(x):
	return x**2
	
t_input = float(sys.argv[1])
print(squared(t_input))