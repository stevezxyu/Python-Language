def my_mean(x):
	summation = 0
	cnt = 0
	for i in x:
		summation += i
		cnt += 1
	return summation / cnt